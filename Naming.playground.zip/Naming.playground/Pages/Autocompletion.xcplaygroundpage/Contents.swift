let numberOfDogs = 8
let numberOfCats = 5
let numberOfTurtles = 3
let numberOfHamsters = 2
let totalNumbersOfAnimals = numberOfDogs + numberOfCats + numberOfTurtles + numberOfHamsters
let totalNumberOfMammals = numberOfDogs + numberOfCats + numberOfHamsters
